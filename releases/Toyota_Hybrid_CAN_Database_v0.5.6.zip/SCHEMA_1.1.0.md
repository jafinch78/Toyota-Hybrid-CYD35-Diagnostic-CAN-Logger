# Toyota Hybrid CAN Database schema 1.1.0

Schema 1.1.0 adds field-level policy metadata without increasing the 44-definition catalog.

- **Evidence grade:** CONFIRMED, PROBABLE, CANDIDATE, or FIELD_SPECIFIC at definition scope.
- **Display policy:** normal-display eligible, probable-marked, hidden/evidence-only, profile-detection-only, privacy-masked, or control/write quarantine.
- **Polling policy:** passive/no-TX, profile-gated read-only, excluded from active polling, or never transmit.
- **Provenance:** source sessions are attached to each field/repeat member.
- **Safety invariant:** database presence is not transmission authorization. Candidate and quarantined records cannot enter an active polling list.
- **Profile gate:** profile-specific requests require authoritative identity; response fingerprints alone remain supporting evidence.
- **External tester rule:** detected external tester traffic is evidence-only, disables CYD active diagnostics, and returns TWAI to LISTEN_ONLY.

Field-specific corrections in v0.5.6:

- ZVW35 0x2192: minimum block voltage and block count CONFIRMED; minimum-block index PROBABLE; maximum voltage/index CANDIDATE. Derive HV spread from 0x2181's eight validated aggregate block voltages.
- ZVW35 0x2198: discharge-control limit PROBABLE; supported current, charge-control and SOC fields remain CONFIRMED.
- ZVW35 0x2187: TI1-TI4 and TB1-TB12 remain CONFIRMED; this does not imply 56 individual cell voltages.
