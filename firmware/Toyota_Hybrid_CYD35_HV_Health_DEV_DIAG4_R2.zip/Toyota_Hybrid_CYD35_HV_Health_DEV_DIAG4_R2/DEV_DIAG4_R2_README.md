# Toyota Hybrid CYD35 HV Health DEV-DIAG4-R2

## Purpose
Controlled follow-on to DEV-DIAG4 for the board-specific stability investigation.

Functional architecture remains DEV2.5 with the DIAG4 primary CAN queue reduction:
- primary CAN queue: 768 CapturedFrame records (18,432 B payload)
- diagnostic queue retained: 64 CapturedFrame records
- automatic/read-only diagnostic polling retained
- external diagnostic observer/reassembly retained
- BLE CAN Sync retained
- raw SD logging retained
- SPEED/WHEELS and PLOT DEV2.5 functionality retained

DIAG4-R2 adds measurement instrumentation only. It does not intentionally remove or add vehicle-control behavior.

## Memory/resource telemetry
Each `# DIAG4_MEM` Serial record includes:
- stage and milliseconds
- free heap / minimum free heap
- largest 8-bit-capable block
- internal-capable free heap
- largest internal-capable block
- heap integrity result
- primary CAN queue occupancy and free slots
- diagnostic queue occupancy and free slots
- BLE command and BLE sync queue occupancy
- logging / BLE / DIAG / TWAI-normal / SD state

## Sequential checkpoints
Setup:
- BOOT
- TFT_READY
- BLE_SERVICE
- CAN_QUEUES
- SD_STAGE
- TWAI_READY
- SETUP_COMPLETE
- DIAG4_BLE_CONNECTED / DIAG4_BLE_DISCONNECTED

START path:
- DIAG4_PRE_START
- DIAG4_POST_DIR
- DIAG4_POST_RAW
- DIAG4_POST_DECODED
- DIAG4_POST_DIAGNOSTIC
- DIAG4_POST_EVENTS
- DIAG4_POST_SYNC
- DIAG4_POST_EXTERNAL_DIAG
- DIAG4_POST_HEADERS
- DIAG4_PRE_SESSION_OPEN
- DIAG4_POST_SESSION_OPEN
- DIAG4_PRE_METADATA
- DIAG4_POST_README
- DIAG4_POST_SIGNALS
- DIAG4_POST_MANIFEST
- DIAG4_POST_CHECKPOINT
- DIAG4_POST_METADATA
- DIAG4_START_DONE
- DIAG4_BLE_NOTIFY_PRE / DIAG4_BLE_NOTIFY_POST

Active:
- DIAG4_ACTIVE_2S
- DIAG4_ACTIVE_5S

STOP path:
- DIAG4_STOP_BEGIN
- DIAG4_STOP_POST_FLUSH
- DIAG4_STOP_POST_MANIFEST
- DIAG4_STOP_POST_CHECKPOINT
- DIAG4_STOP_POST_FILES
- DIAG4_STOP_DONE
- DIAG4_BLE_NOTIFY_PRE / DIAG4_BLE_NOTIFY_POST

## Panic/reset breadcrumb
The most recent checkpoint is retained in RTC memory. On the next boot the prior snapshot is printed as `# DIAG4_PRIOR` and, after SD initializes, appended to:

`/DEV_DIAG4_RESET_AUDIT.CSV`

This is intended to identify the last completed stage and resource state if a panic/reset occurs before normal logging can finish.

## Board comparison fields
`# DIAG4_BOARD` records boot count, reset reason, low 16 bits of eFuse MAC (for distinguishing boards in logs), chip revision, CPU MHz, CAN queue length and CapturedFrame size.

## Suggested controlled comparison
Use the same SD card, vehicle, Android app, capture procedure and compiler/toolchain where practical.

1. Known-good CYD: boot, connect BLE, START/STOP at least 3 times.
2. Suspect CYD: repeat the identical sequence.
3. Preserve Serial output and SD contents, especially `DEV_DIAG4_RESET_AUDIT.CSV` after any reboot/panic.
4. Compare stage-by-stage `internal_free`, `internal_largest`, `integrity`, queue occupancy and reset reason.

This test is designed to distinguish a common software boundary condition from one board consistently crossing that boundary earlier.

## Verification status
Static source-contract tests and ZIP/read-back verification are included in the package. No Arduino/ESP32 compiler is available in the current generation environment, so this package has not been compile-verified here.
