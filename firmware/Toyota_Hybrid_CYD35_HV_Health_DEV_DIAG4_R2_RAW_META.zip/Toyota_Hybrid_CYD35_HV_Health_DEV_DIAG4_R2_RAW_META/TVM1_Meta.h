#pragma once
#include <stdint.h>
#include <stddef.h>
#include <FS.h>

constexpr uint16_t TVM1_SYNC_WORD = 0xA55A;
constexpr uint16_t TVM1_HEADER_SIZE = 32;
constexpr uint16_t TVM1_RECORD_BASE_SIZE = 24;
constexpr uint16_t TVM1_MAX_PAYLOAD = 384;
constexpr uint16_t TVM1_MAX_RECORD = TVM1_RECORD_BASE_SIZE + TVM1_MAX_PAYLOAD;

constexpr uint16_t TVM1_SESSION_START       = 0x0001;
constexpr uint16_t TVM1_STREAM_REGISTER     = 0x0002;
constexpr uint16_t TVM1_STREAM_START        = 0x0003;
constexpr uint16_t TVM1_STREAM_STOP         = 0x0004;
constexpr uint16_t TVM1_STREAM_FILE_OPEN    = 0x0005;
constexpr uint16_t TVM1_STREAM_FILE_CLOSE   = 0x0006;
constexpr uint16_t TVM1_CLOCK_SYNC          = 0x0010;
constexpr uint16_t TVM1_USER_MARKER         = 0x0011;
constexpr uint16_t TVM1_HEALTH_SNAPSHOT     = 0x0020;
constexpr uint16_t TVM1_STREAM_COUNTERS     = 0x0021;
constexpr uint16_t TVM1_STORAGE_HEALTH      = 0x0022;
constexpr uint16_t TVM1_EVENT               = 0x0030;
constexpr uint16_t TVM1_DIAGNOSTIC_STATE    = 0x0031;
constexpr uint16_t TVM1_BUS_STATE           = 0x0032;
constexpr uint16_t TVM1_SESSION_CLOSE       = 0x00FE;

uint32_t tvm1_crc32(const uint8_t *data, size_t len);
void tvm1_put_u16(uint8_t *p, uint16_t v);
void tvm1_put_u32(uint8_t *p, uint32_t v);
void tvm1_put_u64(uint8_t *p, uint64_t v);

class Tvm1Writer {
public:
  Tvm1Writer();
  bool begin(File &file, uint32_t sessionNumber, uint64_t sessionCreateUs);
  bool append(uint16_t recordType, uint8_t streamId, uint8_t flags,
              uint64_t timeUs, const uint8_t *payload, uint16_t payloadLen);
  bool flush();
  uint32_t sequence() const { return sequence_; }
private:
  File *file_;
  uint32_t sequence_;
  uint8_t record_[TVM1_MAX_RECORD];
};
