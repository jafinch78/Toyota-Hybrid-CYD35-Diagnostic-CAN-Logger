# Toyota Hybrid CAN Database v0.5.7

Released: 2026-09-07  
Schema: 1.1.1  
Evidence cutoff: S0062

## Corrective outcome

v0.5.7 preserves v0.5.6 and corrects its omitted S0047 discovery registry. The validated definition count remains **44**. The added discovery inventory contains **93 candidate response shapes** representing **91 unique request tuples**.

- Corrects the v0.5.6 omission by preserving all 93 S0047 response-signature candidate shapes in a dedicated evidence-only registry.
- Reconciles the counts explicitly: 93 response shapes collapse to 91 unique request tuples because two tuples each have two observed shapes; independently, excluding two Mode 09 identity shapes also leaves 91 non-Mode09 shapes.
- Retains all 44 graded decoder definitions unchanged. None of the 93 candidate rows overlaps a graded definition tuple.
- Catalog totals are 137 rows (44 graded definitions plus 93 candidate shapes) and 135 unique request tuples (44 plus 91).
- All S0047 candidates remain CANDIDATE, READ_ONLY_DIAGNOSTIC, automatic-promotion disabled, hidden/evidence-only, and excluded from active polling.
- S0047 proves observed diagnostic response existence and shape, not formula correctness or semantic validation; Evidence Builder 1.0.3 produced zero decoded-field rows and zero local CAN/OCR validation pairs for this session.
- No graded definition, formula, display eligibility, firmware, Evidence Builder, Evidence Analyzer, acquisition, SD, BLE, session, TWAI, or Wi-Fi-transfer code is changed.

## Rollback

The immediate rollback target is Toyota_Hybrid_CAN_Database_v0.5.6.xlsx. v0.5.6 and all earlier evidence artifacts remain unchanged.
