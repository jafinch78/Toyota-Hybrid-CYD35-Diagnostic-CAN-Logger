#include "TVM1_SessionMeta.h"
#include <string.h>

namespace {
constexpr uint8_t TVM1_STREAM_SESSION = 0;
constexpr uint8_t TVM1_STREAM_CAN = 1;
constexpr uint8_t TVM1_STREAM_TYPE_CAN = 1;
constexpr uint8_t TVM1_RAW_FORMAT_TCB1 = 1;
constexpr uint8_t TVM1_DIRECTION_RX_TX = 3;

void put_i64(uint8_t *p, int64_t v) { tvm1_put_u64(p, (uint64_t)v); }
}

Tvm1SessionMeta::Tvm1SessionMeta() : active_(false) {}

bool Tvm1SessionMeta::appendString(uint8_t *buffer, uint16_t capacity, uint16_t &offset, const char *value) {
  if (value == nullptr) value = "";
  size_t n = strlen(value);
  if (n > 255 || offset + 2 + n > capacity) return false;
  tvm1_put_u16(buffer + offset, (uint16_t)n);
  offset += 2;
  if (n) memcpy(buffer + offset, value, n);
  offset += (uint16_t)n;
  return true;
}

bool Tvm1SessionMeta::begin(File &file, uint32_t sessionNumber, uint64_t sessionCreateUs,
                            const char *loggerName, const char *firmwareVersion,
                            const char *boardProfile, const char *buildId,
                            const char *runtimeDatabase, uint32_t canBitrate) {
  active_ = false;
  if (!writer_.begin(file, sessionNumber, sessionCreateUs)) return false;

  uint8_t payload[TVM1_MAX_PAYLOAD] = {};
  uint16_t offset = 0;
  if (!appendString(payload, sizeof(payload), offset, loggerName) ||
      !appendString(payload, sizeof(payload), offset, firmwareVersion) ||
      !appendString(payload, sizeof(payload), offset, boardProfile) ||
      !appendString(payload, sizeof(payload), offset, buildId) ||
      !appendString(payload, sizeof(payload), offset, runtimeDatabase)) return false;
  if (!writer_.append(TVM1_SESSION_START, TVM1_STREAM_SESSION, 0, sessionCreateUs, payload, offset)) return false;

  uint8_t stream[12] = {};
  stream[0] = TVM1_STREAM_TYPE_CAN;
  stream[1] = TVM1_RAW_FORMAT_TCB1;
  stream[2] = 1; // TCB1 major
  stream[3] = 0; // TCB1 minor
  stream[4] = TVM1_DIRECTION_RX_TX;
  stream[5] = 1; // config version
  tvm1_put_u16(stream + 6, 0); // no config extension
  tvm1_put_u32(stream + 8, canBitrate);
  if (!writer_.append(TVM1_STREAM_REGISTER, TVM1_STREAM_CAN, 0, sessionCreateUs, stream, sizeof(stream))) return false;
  if (!writer_.append(TVM1_STREAM_START, TVM1_STREAM_CAN, 0, sessionCreateUs, nullptr, 0)) return false;
  active_ = true;
  return true;
}

bool Tvm1SessionMeta::writeRawFileOpen(uint16_t fileIndex, const char *filename, uint64_t timeUs) {
  if (!active_) return false;
  uint8_t payload[96] = {};
  uint16_t offset = 0;
  tvm1_put_u16(payload + offset, fileIndex); offset += 2;
  if (!appendString(payload, sizeof(payload), offset, filename)) return false;
  return writer_.append(TVM1_STREAM_FILE_OPEN, TVM1_STREAM_CAN, 0, timeUs, payload, offset);
}

bool Tvm1SessionMeta::writeRawFileClose(uint16_t fileIndex, uint64_t recordsPersisted,
                                        uint64_t bytesPersisted, uint64_t timeUs) {
  if (!active_) return false;
  uint8_t payload[20] = {};
  tvm1_put_u16(payload + 0, fileIndex);
  tvm1_put_u16(payload + 2, 0);
  tvm1_put_u64(payload + 4, recordsPersisted);
  tvm1_put_u64(payload + 12, bytesPersisted);
  return writer_.append(TVM1_STREAM_FILE_CLOSE, TVM1_STREAM_CAN, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::writeClockSync(uint16_t sequence, uint64_t receiveUs, uint64_t sendUs,
                                     const char *source) {
  if (!active_) return false;
  uint8_t payload[12] = {};
  tvm1_put_u16(payload + 0, sequence);
  payload[2] = (source && strcmp(source, "BLE") == 0) ? 0 :
               (source && strcmp(source, "BLE_PRESTART") == 0) ? 1 : 255;
  payload[3] = 0;
  tvm1_put_u64(payload + 4, sendUs);
  return writer_.append(TVM1_CLOCK_SYNC, TVM1_STREAM_SESSION, 0, receiveUs, payload, sizeof(payload));
}

uint16_t Tvm1SessionMeta::eventCode(const char *eventName) const {
  if (!eventName) return 65535;
  struct Pair { const char *name; uint16_t code; };
  static const Pair table[] = {
    {"LOGGING_STARTED",1},{"LOGGING_STOP_REQUESTED",2},{"LOGGING_STOPPED",3},
    {"CAN_TRAFFIC_STARTED",4},{"RAW_ROTATION_FAILED",5},{"EXTERNAL_TESTER_DETECTED",6},
    {"TWAI_START_FAILED",7},{"TWAI_TRANSMIT_BLOCKED",8},{"TWAI_TRANSMIT_FAILED",9},
    {"TWAI_MODE_CHANGE_FAILED",10},{"BLE_CAPTURE_START",11},{"BLE_CAPTURE_STOP",12},
    {"BLE_MARKER",13},{"DIAGNOSTIC_ENABLE_REJECTED",14},{"DIAGNOSTIC_IDENTITY_UNRESOLVED",15},
    {"DIAGNOSTIC_RUNTIME_DECODE_MISSING",16},{"DATABASE_PROFILE_EVIDENCE",17},
    {"PROFILE_CHANGE",18},{"DIAGNOSTIC_IDENTITY_FALLBACK",19}
  };
  for (const Pair &p : table) if (strcmp(eventName, p.name) == 0) return p.code;
  return 65535;
}

uint8_t Tvm1SessionMeta::severityCode(const char *severity) const {
  if (!severity) return 0;
  if (strcmp(severity, "WARNING") == 0) return 1;
  if (strcmp(severity, "ERROR") == 0) return 2;
  if (strcmp(severity, "FATAL") == 0) return 3;
  return 0;
}

bool Tvm1SessionMeta::writeEvent(uint64_t timeUs, const char *severity, const char *eventName,
                                 int32_t profile, int32_t confidence) {
  if (!active_) return false;
  uint8_t payload[32] = {};
  const uint16_t code = eventCode(eventName);
  tvm1_put_u16(payload + 0, code);
  payload[2] = severityCode(severity);
  uint8_t count = 0;
  uint16_t offset = 4;
  if ((code == 17 || code == 18) && profile >= 0 && confidence >= 0) {
    tvm1_put_u16(payload + offset + 0, 5); tvm1_put_u16(payload + offset + 2, 0); put_i64(payload + offset + 4, profile); offset += 12; ++count;
    tvm1_put_u16(payload + offset + 0, 6); tvm1_put_u16(payload + offset + 2, 0); put_i64(payload + offset + 4, confidence); offset += 12; ++count;
  }
  payload[3] = count;
  return writer_.append(TVM1_EVENT, TVM1_STREAM_SESSION, 0, timeUs, payload, offset);
}

bool Tvm1SessionMeta::writeCounters(uint64_t timeUs, uint64_t rxRecords, uint64_t txRecords,
                                    uint64_t persistedRecords, uint64_t queueDrops,
                                    uint64_t storageDroppedRecords, uint32_t queueHighWater,
                                    uint32_t protocolErrors) {
  if (!active_) return false;
  uint8_t payload[48] = {};
  tvm1_put_u64(payload + 0, rxRecords);
  tvm1_put_u64(payload + 8, txRecords);
  tvm1_put_u64(payload + 16, persistedRecords);
  tvm1_put_u64(payload + 24, queueDrops);
  tvm1_put_u64(payload + 32, storageDroppedRecords);
  tvm1_put_u32(payload + 40, queueHighWater);
  tvm1_put_u32(payload + 44, protocolErrors);
  return writer_.append(TVM1_STREAM_COUNTERS, TVM1_STREAM_CAN, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::writeHealthSnapshot(uint64_t timeUs) {
  if (!active_) return false;
  uint8_t payload[4] = {};
  tvm1_put_u16(payload + 0, 1); // schema version
  tvm1_put_u16(payload + 2, 0); // no generic metrics yet
  return writer_.append(TVM1_HEALTH_SNAPSHOT, TVM1_STREAM_SESSION, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::writeStorageHealth(uint64_t timeUs, uint64_t cardBytes, uint64_t usedBytes) {
  if (!active_) return false;
  uint8_t payload[28] = {};
  tvm1_put_u16(payload + 0, 1);
  tvm1_put_u16(payload + 2, 2);
  tvm1_put_u16(payload + 4, 1); tvm1_put_u16(payload + 6, 0); tvm1_put_u64(payload + 8, cardBytes);
  tvm1_put_u16(payload + 16, 2); tvm1_put_u16(payload + 18, 0); tvm1_put_u64(payload + 20, usedBytes);
  return writer_.append(TVM1_STORAGE_HEALTH, TVM1_STREAM_SESSION, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::writeDiagnosticState(uint64_t timeUs, bool enabled, uint32_t profile, uint32_t confidence) {
  if (!active_) return false;
  uint8_t payload[12] = {};
  tvm1_put_u16(payload + 0, enabled ? 1 : 0);
  tvm1_put_u16(payload + 2, 0);
  tvm1_put_u32(payload + 4, profile);
  tvm1_put_u32(payload + 8, confidence);
  return writer_.append(TVM1_DIAGNOSTIC_STATE, TVM1_STREAM_SESSION, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::writeBusState(uint64_t timeUs, bool normalMode, uint32_t bitrate, uint32_t externalTesterRecent) {
  if (!active_) return false;
  uint8_t payload[12] = {};
  tvm1_put_u16(payload + 0, normalMode ? 2 : 1);
  tvm1_put_u16(payload + 2, 0);
  tvm1_put_u32(payload + 4, bitrate);
  tvm1_put_u32(payload + 8, externalTesterRecent);
  return writer_.append(TVM1_BUS_STATE, TVM1_STREAM_CAN, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::writeStreamStop(uint16_t reasonCode, uint64_t timeUs) {
  if (!active_) return false;
  uint8_t payload[2] = {};
  tvm1_put_u16(payload, reasonCode);
  return writer_.append(TVM1_STREAM_STOP, TVM1_STREAM_CAN, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::writeSessionClose(bool clean, uint16_t reasonCode, uint64_t timeUs) {
  if (!active_) return false;
  uint8_t payload[8] = {};
  tvm1_put_u16(payload + 0, reasonCode);
  payload[2] = clean ? 1 : 0;
  payload[3] = 0;
  tvm1_put_u16(payload + 4, 1);
  tvm1_put_u16(payload + 6, 0);
  return writer_.append(TVM1_SESSION_CLOSE, TVM1_STREAM_SESSION, 0, timeUs, payload, sizeof(payload));
}

bool Tvm1SessionMeta::flush() { return active_ ? writer_.flush() : false; }
void Tvm1SessionMeta::end() { active_ = false; }
