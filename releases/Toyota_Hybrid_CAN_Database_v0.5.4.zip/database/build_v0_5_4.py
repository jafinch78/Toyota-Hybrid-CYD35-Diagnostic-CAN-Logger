#!/usr/bin/env python3
"""Build Toyota Hybrid CAN Database v0.5.4 from the reviewed v0.5.3 base.

The build is deterministic and intentionally preserves all v0.5.3 definitions.
New definitions remain profile-isolated and retain their evidence and safety grades.
"""

from __future__ import annotations

import json
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "toyota_hybrid_can_db_v0.5.3.json"
OUTPUT = ROOT / "toyota_hybrid_can_db_v0.5.4.json"


def read_only(
    *, key: str, profile: str, request_id: str, response_id: str, pid: str,
    decoder: str, grade: str, source: str, **extra: object
) -> dict[str, object]:
    definition: dict[str, object] = {
        "key": key,
        "profile": profile,
        "request_id": request_id,
        "response_id": response_id,
        "service": "21",
        "pid": pid,
        "response_prefix": f"61{pid}",
        "decoder": decoder,
        "safety_class": "READ_ONLY_DIAGNOSTIC",
        "evidence_grade": grade,
        "transport": "ISO-TP",
        "source": source,
    }
    definition.update(extra)
    return definition


def main() -> None:
    data = json.loads(SOURCE.read_text(encoding="utf-8"))
    data["version"] = "0.5.4"
    data["released_utc"] = "2026-08-31T00:00:00Z"
    data["rollback"] = "Toyota_Hybrid_CAN_Database_v0.5.3.xlsx"
    data["profiles"]["PRIUS_PHV_GEN1"] = {
        "platform": "ZVW35",
        "block_count": 8,
        "cell_count": 56,
        "cells_per_block": 7,
        "chemistry": "Lithium-ion NMC",
        "individual_cell_values_available": False,
        "notes": "Observed 2181 values are eight seven-cell aggregate block voltages; no validated 56-cell decoder is present.",
    }
    data["profiles"]["PRIUS_GEN2"].update({
        "cell_count": 168,
        "cells_per_block": 12,
        "chemistry": "NiMH",
    })
    data["profiles"]["CAMRY_HYBRID_GEN1"].update({
        "cell_count": 204,
        "cells_per_block": 12,
        "chemistry": "NiMH",
    })

    # Promote the existing Camry 21CE layout after independent S0017 AP200
    # screen-to-CAN corroboration. S0017 is a passive CYD observation; the
    # external AP200 generated the read-only diagnostic requests.
    camry_21ce = next(item for item in data["definitions"] if item["key"] == "AHV40_HYBRID_ECU_21CE_BLOCK_VOLTAGES")
    camry_21ce["source"] = "S0010, S0012, S0013, and S0017 2007 Camry Hybrid; Hybrid Assistant, Dr. Prius, and Autel MAXIAP200; CYD logger v2.4.2"
    camry_21ce["evidence_grade"] = "CONFIRMED"
    camry_21ce["fields"] = [
        {"name": "battery_soc", "offset": 0, "width_bytes": 1, "formula": "A/2", "unit": "%"},
        {"name": "battery_current", "offset": 1, "width_bytes": 2, "endian": "big", "formula": "uint16/100-327.68", "unit": "A"},
    ]
    camry_21ce["validation"] = (
        "Three sessions reconstructed the 17-block array. S0013 contained 237 decodable 21CE segments and 84 time-aligned graph rows; "
        "median all-row CAN-to-OCR block RMSE was 0.021144 V. Independent S0017 Autel MAXIAP200 correlation supplied 34 successful transactions; "
        "77 of 79 OCR block labels matched exactly, median best-nearby RMSE was 0.000 V, and displayed SoC/current examples matched exactly."
    )
    camry_21ce["observations"] = {
        "sessions": ["S0010", "S0012", "S0013", "S0017"],
        "s0013_decodable_segments": 237,
        "s0013_aligned_graph_rows": 84,
        "s0017_successful_transactions": 34,
        "s0017_ocr_block_values_compared": 79,
        "s0017_exact_block_value_matches": 77,
        "s0017_median_best_nearby_rmse_v": 0.0,
        "s0017_maximum_best_nearby_rmse_v": 0.018898223650460958,
    }

    nhw20_source = "S0016 2004 Prius Gen 2; Autel MAXIAP200 OCR/CAN correlation; CYD logger v2.4.2"
    camry_source = "S0012, S0013, and S0017 2007 Camry Hybrid; passive diagnostic observation with Hybrid Assistant, Dr. Prius, and Autel MAXIAP200; CYD logger v2.4.2"
    phv_source = "S0015 2014 Prius PHV Gen 1; Hybrid Assistant/Dr. Prius OCR/CAN correlation; CYD logger v2.4.2"

    additions = [
        read_only(
            key="NHW20_BATTERY_ECU_21CE_SOC_CURRENT_BLOCK_VOLTAGES",
            profile="PRIUS_GEN2", request_id="7E3", response_id="7EB", pid="CE",
            decoder="block_array", grade="CONFIRMED", source=nhw20_source,
            preamble_bytes=3,
            fields=[
                {"name": "battery_soc", "offset": 0, "width_bytes": 1, "formula": "A/2", "unit": "%"},
                {"name": "battery_current", "offset": 1, "width_bytes": 2, "endian": "big", "formula": "uint16/100-327.68", "unit": "A"},
            ],
            repeat={"name": "block_voltage", "count": 14, "width_bytes": 2, "endian": "big", "offset": -32768, "scale": 0.01, "unit": "V"},
            bounds={"minimum": 10.0, "maximum": 20.0},
            observations={"successful_transactions": 61, "exact_ap200_ocr_matches": True},
            validation="AP200-displayed SoC, current, and all 14 block voltages were reproduced from the same diagnostic responses.",
        ),
        read_only(
            key="NHW20_BATTERY_ECU_21D0_BLOCK_HEALTH",
            profile="PRIUS_GEN2", request_id="7E3", response_id="7EB", pid="D0",
            decoder="block_health_array", grade="CONFIRMED", source=nhw20_source,
            fields=[
                {"name": "block_count", "offset": 0, "width_bytes": 1, "formula": "A", "expected": 14},
                {"name": "reported_voltage_value_1", "offset": 9, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "V", "semantic_status": "CANDIDATE_EXTREMA"},
                {"name": "reported_voltage_index_1", "offset": 11, "width_bytes": 1, "formula": "L", "semantic_status": "CANDIDATE_INDEX"},
                {"name": "reported_voltage_value_2", "offset": 12, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "V", "semantic_status": "CANDIDATE_EXTREMA"},
                {"name": "reported_voltage_index_2", "offset": 14, "width_bytes": 1, "formula": "O", "semantic_status": "CANDIDATE_INDEX"},
            ],
            repeat={"name": "block_internal_resistance", "offset": 15, "count": 14, "width_bytes": 1, "scale": 0.001, "unit": "ohm"},
            observations={"successful_transactions": 73, "exact_ap200_ocr_matches": True},
            validation="Fourteen resistance values and displayed block-health values matched AP200. Extrema/index labels remain explicitly candidate semantics.",
        ),
        read_only(
            key="AHV40_ENGINE_ECU_21C1_MODEL_SIGNATURE",
            profile="CAMRY_HYBRID_GEN1", request_id="7E0", response_id="7E8", pid="C1",
            decoder="ascii_model_signature", grade="CONFIRMED", source=camry_source,
            signature={"ascii_contains": "AHV40L", "minimum_response_bytes": 18},
            observations={"sessions": ["S0012", "S0013", "S0017"], "response_ascii_prefix": "AHV40L 2AZFXE", "s0017_successful_transactions": 20},
            validation="The 7E0/21C1 AHV40L model signature was observed in S0012/S0013 and twenty times during the S0017 AP200 scan.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_21C1_MODEL_SIGNATURE",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="C1",
            decoder="ascii_model_signature", grade="CONFIRMED", source=camry_source,
            signature={"ascii_contains": "AHV40L", "minimum_response_bytes": 18},
            observations={"sessions": ["S0017"], "response_ascii_prefix": "AHV40L 2AZFXE", "successful_transactions": 10},
            validation="Ten S0017 7E2/21C1 responses contained AHV40L 2AZFXE and matched the AP200 Model code AHV40L display.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_21D0_BLOCK_HEALTH",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="D0",
            decoder="block_health_array", grade="CONFIRMED", source=camry_source,
            fields=[
                {"name": "block_count", "offset": 0, "width_bytes": 1, "formula": "A", "expected": 17},
                {"name": "minimum_block_voltage", "offset": 9, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "V"},
                {"name": "minimum_block_number", "offset": 11, "width_bytes": 1, "formula": "L+1", "unit": "1-based block"},
                {"name": "maximum_block_voltage", "offset": 12, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "V"},
                {"name": "maximum_block_number", "offset": 14, "width_bytes": 1, "formula": "O+1", "unit": "1-based block"},
            ],
            repeat={"name": "block_internal_resistance", "offset": 15, "count": 17, "width_bytes": 1, "scale": 0.001, "unit": "ohm"},
            observations={"s0012_bundled_transactions": 81, "s0013_bundled_transactions": 81, "s0013_standalone_transactions": 1, "s0017_successful_transactions": 59},
            validation="S0017 AP200 labels confirmed block count, minimum/maximum voltages, one-based block numbers, and all 17 resistance values; raw 0x13 displayed as 0.019 ohm.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_21C3_MG_TEMPERATURES",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="C3",
            decoder="field_map", grade="CONFIRMED", source=camry_source,
            signature={"response_length_bytes": 40},
            fields=[
                {"name": "mg1_inverter_temperature", "offset": 18, "width_bytes": 1, "formula": "S-50", "unit": "degC"},
                {"name": "mg2_inverter_temperature", "offset": 19, "width_bytes": 1, "formula": "T-50", "unit": "degC"},
                {"name": "mg1_motor_temperature", "offset": 20, "width_bytes": 1, "formula": "U-50", "unit": "degC"},
                {"name": "mg2_motor_temperature", "offset": 21, "width_bytes": 1, "formula": "V-50", "unit": "degC"},
            ],
            observations={"s0013_successful_transactions": 270, "s0017_successful_transactions": 71},
            validation="S0017 AP200 labels exactly matched inverter temperatures 27/27 degC and motor temperatures 26/25 or 27/25 degC.",
            notes="Only the four listed fields are confirmed; all other 21C3 bytes remain candidate/unknown.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_21C4_SIGNATURE",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="C4",
            decoder="response_signature", grade="CANDIDATE", source=camry_source,
            signature={"response_length_bytes": 17}, observations={"s0013_successful_transactions": 276},
            notes="Useful as a profile fingerprint only; field meanings are not inferred.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_21CF_BATTERY_TEMPERATURES",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="CF",
            decoder="field_map", grade="CONFIRMED", source=camry_source,
            signature={"response_length_bytes": 30},
            fields=[
                {"name": "battery_inhaling_air_temperature", "offset": 0, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "degC"},
                {"name": "battery_temperature_1", "offset": 10, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "degC"},
                {"name": "battery_temperature_2", "offset": 12, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "degC"},
                {"name": "battery_temperature_3", "offset": 14, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "degC"},
                {"name": "battery_temperature_4", "offset": 16, "width_bytes": 2, "endian": "big", "formula": "(uint16-32768)/100", "unit": "degC"},
            ],
            observations={"s0013_standalone_transactions": 68, "s0013_bundled_transactions": 81, "s0017_successful_transactions": 35},
            validation="S0017 AP200 labels matched battery intake and temperatures 1-4, including 27.49, 27.95, 28.07, and 27.37 degC examples.",
            notes="Only the five listed fields are confirmed; all other 21CF bytes remain candidate/unknown.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_2105_ENGINE_COOLANT_TEMPERATURE",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="05",
            decoder="field_map", grade="CONFIRMED", source=camry_source,
            fields=[{"name": "engine_coolant_temperature", "offset": 0, "width_bytes": 1, "formula": "A-40", "unit": "degC"}],
            observations={"s0017_successful_transactions": 5},
            validation="S0017 byte 0x53 decoded to 43 degC and matched the AP200 label.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_210F_INTAKE_AIR_TEMPERATURE",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="0F",
            decoder="field_map", grade="CONFIRMED", source=camry_source,
            fields=[{"name": "intake_air_temperature", "offset": 0, "width_bytes": 1, "formula": "A-40", "unit": "degC"}],
            observations={"s0017_successful_transactions": 5},
            validation="S0017 byte 0x4C decoded to 36 degC and matched the AP200 label.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_210C_ENGINE_SPEED",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="0C",
            decoder="field_map", grade="CONFIRMED", source=camry_source,
            fields=[{"name": "engine_speed", "offset": 0, "width_bytes": 2, "endian": "big", "formula": "uint16/4", "unit": "rpm"}],
            observations={"s0017_successful_transactions": 4},
            validation="S0017 0x0000 decoded to 0 rpm and matched the stationary AP200 label.",
        ),
        read_only(
            key="AHV40_HYBRID_ECU_211F_ENGINE_RUN_TIME",
            profile="CAMRY_HYBRID_GEN1", request_id="7E2", response_id="7EA", pid="1F",
            decoder="field_map", grade="CONFIRMED", source=camry_source,
            fields=[{"name": "engine_run_time", "offset": 0, "width_bytes": 2, "endian": "big", "formula": "uint16", "unit": "s"}],
            observations={"s0017_successful_transactions": 3},
            validation="S0017 0x0053 decoded to 83 seconds and matched the AP200 label.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2101_ENGINE_AND_SOC",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="01",
            decoder="field_map", grade="PROBABLE", source=phv_source,
            fields=[
                {"name": "calculated_load", "offset": 0, "formula": "A*20/51", "unit": "%"},
                {"name": "manifold_pressure", "offset": 1, "formula": "B", "unit": "kPa"},
                {"name": "intake_air_temperature", "offset": 2, "formula": "C*1.8-40", "unit": "degF"},
                {"name": "ambient_temperature", "offset": 3, "formula": "D*1.8-40", "unit": "degF"},
                {"name": "coolant_temperature", "offset": 5, "formula": "F*1.8-40", "unit": "degF"},
                {"name": "engine_rpm", "offset": 6, "width_bytes": 2, "endian": "big", "formula": "uint16/4", "unit": "rpm"},
                {"name": "vehicle_speed", "offset": 8, "formula": "I*15625/25146", "unit": "mph"},
                {"name": "runtime", "offset": 9, "width_bytes": 2, "endian": "big", "formula": "uint16", "unit": "s"},
                {"name": "throttle", "offset": 11, "formula": "L*20/51", "unit": "%"},
                {"name": "accelerator_pedal_1", "offset": 12, "formula": "M*20/51", "unit": "%"},
                {"name": "accelerator_pedal_2", "offset": 13, "formula": "N*20/51", "unit": "%"},
                {"name": "auxiliary_battery_voltage", "offset": 19, "width_bytes": 2, "endian": "big", "formula": "uint16/1000", "unit": "V"},
                {"name": "actual_soc", "offset": 21, "formula": "V*20/51", "unit": "%"},
            ],
            observations={"standalone_transactions": 25, "bundled_transactions": 132, "soc_median_absolute_error_percentage_points": 0.00588},
            validation="Actual SoC was time-aligned to app data. Other fields retain source-table formulas and require broader dynamic validation.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2161_MG1_STATUS",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="61",
            decoder="field_map", grade="PROBABLE", source=phv_source,
            fields=[
                {"name": "mg1_temperature", "offset": 0, "formula": "A*1.8-40", "unit": "degF"},
                {"name": "mg1_temperature_history", "offset": 1, "formula": "B*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
                {"name": "mg1_temperature_max", "offset": 2, "formula": "C*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
                {"name": "mg1_rpm", "offset": 3, "width_bytes": 2, "endian": "big", "formula": "uint16-32768", "unit": "rpm"},
            ], observations={"combined_2161_2162_2167_2168_transactions": 260},
            validation="MG1 temperature near 78.8 degF agreed with the displayed app value; historical/max labels remain candidate.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2162_MG2_STATUS",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="62",
            decoder="field_map", grade="CANDIDATE", source=phv_source,
            fields=[
                {"name": "mg2_temperature", "offset": 0, "formula": "A*1.8-40", "unit": "degF"},
                {"name": "mg2_temperature_history", "offset": 1, "formula": "B*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
                {"name": "mg2_temperature_max", "offset": 2, "formula": "C*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
                {"name": "mg2_rpm", "offset": 3, "width_bytes": 2, "endian": "big", "formula": "uint16-32768", "unit": "rpm"},
            ], observations={"combined_2161_2162_2167_2168_transactions": 260},
            notes="Observed repeatedly but not independently label-correlated in S0015.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2167_MG1_TORQUE",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="67",
            decoder="field_map", grade="CANDIDATE", source=phv_source,
            fields=[
                {"name": "mg1_torque_command", "offset": 0, "width_bytes": 2, "endian": "big", "formula": "(uint16/8-4096)*0.7375621", "unit": "ft-lb"},
                {"name": "mg1_torque_execution", "offset": 2, "width_bytes": 2, "endian": "big", "formula": "(uint16/8-4096)*0.7375621", "unit": "ft-lb"},
                {"name": "mg1_control_mode", "offset": 4, "formula": "E"},
            ], observations={"combined_2161_2162_2167_2168_transactions": 260},
            notes="Formula is source-derived; S0015 was parked and did not provide a sufficient dynamic torque range.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2168_MG2_TORQUE",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="68",
            decoder="field_map", grade="CANDIDATE", source=phv_source,
            fields=[
                {"name": "mg2_torque_command", "offset": 0, "width_bytes": 2, "endian": "big", "formula": "(uint16/8-4096)*0.7375621", "unit": "ft-lb"},
                {"name": "mg2_torque_execution", "offset": 2, "width_bytes": 2, "endian": "big", "formula": "(uint16/8-4096)*0.7375621", "unit": "ft-lb"},
                {"name": "mg2_control_mode", "offset": 4, "formula": "E"},
            ], observations={"combined_2161_2162_2167_2168_transactions": 260},
            notes="Formula is source-derived; S0015 was parked and did not provide a sufficient dynamic torque range.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2170_MG1_INVERTER_TEMPERATURE",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="70",
            decoder="field_map", grade="PROBABLE", source=phv_source,
            fields=[
                {"name": "mg1_inverter_temperature", "offset": 0, "formula": "A*1.8-40", "unit": "degF"},
                {"name": "mg1_inverter_temperature_history", "offset": 1, "formula": "B*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
                {"name": "mg1_inverter_temperature_max", "offset": 2, "formula": "C*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
                {"name": "inverter_gate_status", "offset": 3, "formula": "bit(D,0)", "semantic_status": "CANDIDATE_BIT"},
            ], observations={"combined_2170_2171_transactions": 32},
            validation="Current MG1 inverter temperature near 80.6 degF agreed with app display; history/max/gate labels remain candidate.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2171_MG2_INVERTER_TEMPERATURE",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="71",
            decoder="field_map", grade="CANDIDATE", source=phv_source,
            fields=[
                {"name": "mg2_inverter_temperature", "offset": 0, "formula": "A*1.8-40", "unit": "degF"},
                {"name": "mg2_inverter_temperature_history", "offset": 1, "formula": "B*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
                {"name": "mg2_inverter_temperature_max", "offset": 2, "formula": "C*1.8-40", "unit": "degF", "semantic_status": "CANDIDATE_LABEL"},
            ], observations={"combined_2170_2171_transactions": 32},
            notes="Observed but not independently label-correlated in S0015.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2174_BOOST_CONVERTER_TEMPERATURES",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="74",
            decoder="field_map", grade="CANDIDATE", source=phv_source,
            fields=[
                {"name": "boost_converter_temperature_1", "offset": 0, "formula": "A*1.8-40", "unit": "degF"},
                {"name": "boost_converter_temperature_2", "offset": 1, "formula": "B*1.8-40", "unit": "degF"},
                {"name": "boost_converter_temperature_3", "offset": 2, "formula": "C*1.8-40", "unit": "degF"},
                {"name": "boost_converter_temperature_4", "offset": 3, "formula": "D*1.8-40", "unit": "degF"},
                {"name": "converter_status", "offset": 4, "formula": "E", "semantic_status": "CANDIDATE_BITS"},
            ], observations={"successful_transactions": 260},
            notes="Voltage fields intentionally omitted: captured byte order did not support the source-table VL/VH formula.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2181_EIGHT_BLOCK_VOLTAGES",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="81",
            decoder="block_array", grade="PROBABLE", source=phv_source,
            preamble_bytes=0,
            repeat={"name": "seven_cell_block_voltage", "offset": 0, "count": 8, "width_bytes": 2, "endian": "big", "scale": 0.0012205691615167468, "formula": "uint16*79.99/65535", "unit": "V"},
            fields=[
                {"name": "auxiliary_voltage", "offset": 16, "width_bytes": 2, "endian": "big", "formula": "uint16*79.9/65535-40", "unit": "V"},
                {"name": "pack_voltage", "offset": 18, "width_bytes": 2, "endian": "big", "formula": "uint16/10", "unit": "V"},
                {"name": "fan_motor_voltage_1", "offset": 20, "formula": "U/10", "unit": "V"},
                {"name": "fan_motor_voltage_2", "offset": 21, "formula": "V/10", "unit": "V"},
            ],
            bounds={"minimum": 15.0, "maximum": 35.0},
            observations={"standalone_transactions": 150, "bundled_transactions": 132, "strict_aligned_rows": 23, "block_average_median_absolute_error_v": 0.003007, "block_difference_median_absolute_error_v": 0.000105},
            validation="At 94 s all eight decoded seven-cell blocks matched Hybrid Assistant with approximately 0.0005 V RMSE. Values are block aggregates, not individual cells.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2187_BATTERY_TEMPERATURES",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="87",
            decoder="field_map", grade="PROBABLE", source=phv_source,
            fields=[
                {"name": "battery_intake_temperature", "offset": 0, "width_bytes": 2, "endian": "big", "formula": "uint16*255.9/65535*1.8-58", "unit": "degF"},
                {"name": "battery_temperature_1", "offset": 2, "width_bytes": 2, "endian": "big", "formula": "uint16*255.9/65535*1.8-58", "unit": "degF"},
                {"name": "battery_temperature_2", "offset": 4, "width_bytes": 2, "endian": "big", "formula": "uint16*255.9/65535*1.8-58", "unit": "degF"},
                {"name": "battery_temperature_3", "offset": 6, "width_bytes": 2, "endian": "big", "formula": "uint16*255.9/65535*1.8-58", "unit": "degF"},
            ], observations={"standalone_transactions": 89, "bundled_transactions": 132},
            validation="Temperature topology agreed with the PHV source table and app display. Unlabeled trailing bytes remain raw.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2195_BLOCK_INTERNAL_RESISTANCE",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="95",
            decoder="resistance_array", grade="CANDIDATE", source=phv_source,
            repeat={"name": "seven_cell_block_internal_resistance", "offset": 0, "count": 8, "width_bytes": 1, "scale": 0.001, "unit": "ohm"},
            observations={"standalone_transactions": 1, "bundled_transactions": 132},
            notes="Eight values fit the PHV block topology but no independently labeled resistance display was available.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2198_BATTERY_CURRENT_AND_SOC",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="98",
            decoder="field_map", grade="PROBABLE", source=phv_source,
            fields=[
                {"name": "battery_current", "offset": 0, "width_bytes": 2, "endian": "big", "formula": "uint16/100-327.68", "unit": "A"},
                {"name": "charge_control_limit", "offset": 2, "formula": "(C/2-64)*1.341022089595028", "unit": "hp"},
                {"name": "discharge_control_limit", "offset": 3, "formula": "(D/2-64)*1.341022089595028", "unit": "hp"},
                {"name": "delta_soc", "offset": 4, "formula": "E/2", "unit": "%"},
                {"name": "soc_after_ig", "offset": 5, "formula": "F/2", "unit": "%"},
                {"name": "soc_max", "offset": 6, "formula": "G/2", "unit": "%"},
                {"name": "soc_min", "offset": 7, "formula": "H/2", "unit": "%"},
            ], observations={"standalone_transactions": 272, "bundled_transactions": 132, "current_median_absolute_error_a": 0.05},
            validation="Battery current was time-aligned to the app with 0.05 A median absolute error; SoC/control fields retain source-table semantics.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_219B_BATTERY_FAN_STATUS",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="9B",
            decoder="field_map", grade="CANDIDATE", source=phv_source,
            fields=[
                {"name": "battery_ecu_mode", "offset": 0, "formula": "A"},
                {"name": "battery_fan_mode", "offset": 1, "formula": "B"},
                {"name": "standby_blower_request", "offset": 2, "formula": "bit(C,7)"},
                {"name": "blower_voltage", "offset": 3, "formula": "D*4.98/255", "unit": "V"},
            ], observations={"successful_transactions": 31},
            notes="Observed during HVAC narration but not sufficiently time-aligned to promote individual labels.",
        ),
        read_only(
            key="ZVW35_HYBRID_ECU_2146_SIGNATURE",
            profile="PRIUS_PHV_GEN1", request_id="7E2", response_id="7EA", pid="46",
            decoder="response_signature", grade="CANDIDATE", source=phv_source,
            observations={"successful_transactions": 267},
            notes="Repeated PHV diagnostic response retained for fingerprinting; no trusted field formula is assigned.",
        ),
    ]
    data["definitions"].extend(additions)

    data["bundled_requests"] = [
        {
            "profile": "CAMRY_HYBRID_GEN1", "request_id": "7E2", "service": "21", "pids": ["CE", "D0", "CF"],
            "request_payload": "21CED0CF", "evidence_grade": "PROBABLE", "safety_class": "READ_ONLY_DIAGNOSTIC",
            "observations": {"s0012_successful": 81, "s0013_successful": 81},
        },
        {
            "profile": "PRIUS_PHV_GEN1", "request_id": "7E2", "service": "21", "pids": ["01", "81", "95", "87", "98"],
            "request_payload": "210181958798", "evidence_grade": "PROBABLE", "safety_class": "READ_ONLY_DIAGNOSTIC",
            "observations": {"s0015_successful": 132},
        },
        {
            "profile": "PRIUS_PHV_GEN1", "request_id": "7E2", "service": "21", "pids": ["61", "62", "67", "68"],
            "request_payload": "2161626768", "evidence_grade": "CANDIDATE", "safety_class": "READ_ONLY_DIAGNOSTIC",
            "observations": {"s0015_successful": 260},
        },
        {
            "profile": "PRIUS_PHV_GEN1", "request_id": "7E2", "service": "21", "pids": ["70", "71"],
            "request_payload": "217071", "evidence_grade": "CANDIDATE", "safety_class": "READ_ONLY_DIAGNOSTIC",
            "observations": {"s0015_successful": 32},
        },
    ]

    data["profile_signatures"] = [
        {
            "profile": "PRIUS_GEN2", "request_id": "7E3", "service": "21", "pid": "CE", "response_id": "7EB",
            "response_prefix": "61CE", "block_count": 14, "evidence_grade": "CONFIRMED", "detector_weight": 90,
        },
        {
            "profile": "CAMRY_HYBRID_GEN1", "request_id": "7E0", "service": "21", "pid": "C1", "response_id": "7E8",
            "response_ascii_contains": "AHV40L", "evidence_grade": "CONFIRMED", "detector_weight": 100,
        },
        {
            "profile": "CAMRY_HYBRID_GEN1", "request_id": "7E2", "service": "21", "pid": "CE", "response_id": "7EA",
            "response_length_bytes": 39, "block_count": 17, "evidence_grade": "CONFIRMED", "detector_weight": 90,
        },
        {
            "profile": "CAMRY_HYBRID_GEN1", "request_id": "7E2", "service": "21", "pid": "C1", "response_id": "7EA",
            "response_ascii_contains": "AHV40L", "evidence_grade": "CONFIRMED", "detector_weight": 100,
        },
        {
            "profile": "PRIUS_PHV_GEN1", "request_id": "7E2", "service": "21", "pid": "81", "response_id": "7EA",
            "response_length_bytes": 24, "block_count": 8, "block_voltage_bounds_v": [15.0, 35.0], "evidence_grade": "PROBABLE", "detector_weight": 90,
        },
        {
            "profile": "PRIUS_PHV_GEN1", "request_id": "7E2", "request_payload": "210181958798", "response_id": "7EA",
            "response_length_bytes": 100, "evidence_grade": "PROBABLE", "detector_weight": 95,
        },
    ]

    data["capture_evidence"] = {
        "S0013": {
            "vehicle": "2007 Camry Hybrid AHV40", "raw_frames": 505243, "session_transmit_frames": 0,
            "diagnostic_transactions": 1981, "notes": "Same physical vehicle likely used for S0010/S0012/S0013; limits promotion independence.",
        },
        "S0015": {
            "vehicle": "2014 Prius PHV ZVW35", "raw_frames": 573133, "session_transmit_frames": 0,
            "diagnostic_transactions": 2861, "notes": "Logger originally labeled the capture as Camry 95%; v0.5.4 preserves that evidence while adding PHV fingerprints for a future detector update.",
        },
        "S0016": {
            "vehicle": "2004 Prius Gen 2 NHW20", "notes": "Autel MAXIAP200 screen/CAN correlation confirmed 21CE and 21D0.",
        },
        "S0017": {
            "vehicle": "2007 Camry Hybrid AHV40L",
            "logger_version": "2.4.2",
            "raw_frames": 880701,
            "session_transmit_frames": 0,
            "diagnostic_transactions": 954,
            "successful_diagnostic_transactions": 872,
            "alignment_rms_ms": 5.871164159805791,
            "notes": "Autel MAXIAP200 labels independently confirmed 21CE SoC/current/17 block voltages, 21D0 extrema/index/resistance layout, selected 21C3/21CF temperatures, and the 7E2/21C1 AHV40L signature.",
        },
    }

    data["release_notes"] = [
        "Adds confirmed NHW20 21CE state/current/block-voltage and 21D0 block-health definitions from S0016 Autel AP200 correlation.",
        "Uses S0017 Autel MAXIAP200 screen-to-CAN correlation to confirm AHV40 21CE SoC/current/17 block voltages and 21D0 block-health topology.",
        "Confirms selected AHV40 21C3 motor/inverter temperatures, 21CF battery temperatures, 2105 coolant, 210F intake air, 210C RPM, 211F runtime, and a 7E2/21C1 AHV40L model signature.",
        "Adds ZVW35 eight-block, battery-current/SoC, temperature, motor/inverter, converter, fan, resistance, bundle, and profile-signature metadata with conservative evidence grades.",
        "Explicitly records that ZVW35 2181 provides eight seven-cell aggregate block voltages and does not expose 56 independently validated cell voltages.",
        "No new control/write definition is enabled; inherited Mode 04 definitions remain quarantined.",
    ]

    OUTPUT.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"wrote {OUTPUT} with {len(data['definitions'])} definitions")


if __name__ == "__main__":
    main()
