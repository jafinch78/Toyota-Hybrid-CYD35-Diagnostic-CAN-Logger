# HV Health DEV2.3

SPEED screen refinement:
- Keeps large MPH, engine temperature, ICE/MG1/MG2 RPM, SOC, and block delta-V.
- Places HV battery voltage beside block delta-V.
- Places MG1 Motor Temp and MG2 Motor Temp together on the final live-data row.
- Speed-source and tire-size selection remain deferred to a later settings/options UI.

All DEV2.2 acquisition/logger behavior is otherwise retained.
