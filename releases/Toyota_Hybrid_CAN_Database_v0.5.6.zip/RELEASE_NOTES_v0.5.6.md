# Toyota Hybrid CAN Database v0.5.6

Released: 2026-09-07  
Schema: 1.1.0  
Definitions: 44 (unchanged)  
Evidence cutoff: S0062

## Outcome

This database-only release reconciles the supplied v0.5.5 variants and makes the field-level evidence boundary explicit. It does not modify Evidence Builder 1.0.3, Evidence Analyzer, logger firmware, or any acquisition/SD/BLE/session/TWAI/Wi-Fi path.

## Material corrections

- Introduces schema 1.1.0 field-level evidence, display, polling, provenance, and safety metadata while retaining 44 definitions.
- Reconciles the two v0.5.5 workbook variants using Toyota_Hybrid_CAN_Database_v0.5.5(1).xlsx as the content baseline without modifying either source file.
- Refines ZVW35 2192 to field-specific grades: minimum voltage and block count confirmed, minimum index probable, and maximum voltage/index candidate; normal HV spread is derived from confirmed 2181 block values.
- Refines ZVW35 2198 so discharge-control limit remains PROBABLE while supported battery-current, charge-control, delta-SOC, post-IG SOC, and SOC extrema fields remain CONFIRMED.
- Retains ZVW35 2187 TI1-TI4 and TB1-TB12 as confirmed temperature channels and makes no 56-cell voltage claim.
- Adds a reviewed session registry through S0062, including empty, unavailable, unpaired, OCR-profile-mismatched, timing-limited, and drop-affected sessions.
- Candidate fields remain hidden/evidence-only and excluded from active polling; control/write records remain quarantined and never-transmit.
- Profile-specific diagnostic polling requires authoritative identity; observed external tester traffic is evidence-only and disables CYD active diagnostics.
- No Evidence Builder, Evidence Analyzer, logger firmware, SD/BLE/session, acquisition, TWAI, or Wi-Fi-transfer code is changed by this database-only release.

## Safety and compatibility

- Normal display is eligible for CONFIRMED fields. PROBABLE fields require a visible P marker. CANDIDATE fields remain hidden/evidence-only.
- Candidate definitions are excluded from active polling. CONTROL_WRITE_QUARANTINED definitions are never-transmit.
- Database presence never grants CAN transmission authority.
- Profile-specific read-only diagnostics require authoritative vehicle identity; external tester activity disables active diagnostics and returns TWAI to LISTEN_ONLY.
- Live validated display is independent of START LOG; START/STOP/BLE control SD capture only. (Policy carried forward; no firmware change is included.)

## Rollback

Formal rollback target: Toyota_Hybrid_CAN_Database_v0.5.4.xlsx. The immediate reconciled content predecessor is Toyota_Hybrid_CAN_Database_v0.5.5(1).xlsx, retained unchanged alongside the original v0.5.5 workbook.
