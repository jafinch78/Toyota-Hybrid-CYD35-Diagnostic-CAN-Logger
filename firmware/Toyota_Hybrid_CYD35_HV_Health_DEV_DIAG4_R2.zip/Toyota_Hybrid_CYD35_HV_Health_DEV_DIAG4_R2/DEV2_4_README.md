# HV Health DEV2.4

Compile-fix checkpoint derived from DEV2.3.

## Fix
`drawSpeedPage()` no longer references nonexistent `LiveSignals::mgRPMValid` / `mgRPMMs`. It uses the existing MG powertrain freshness state already used by MAIN: `mgPowertrainValid` / `mgPowertrainMs`, with the existing Camry C3 freshness path preserved.

No SPEED layout or signal mapping was otherwise changed.
