# Toyota Hybrid CAN Database v0.5.8

Released: 2026-09-07  
Schema: 1.2.0  
Evidence cutoff: S0062

## Outcome

v0.5.8 normalizes all available candidate registries from S0047 through S0062. It preserves every session observation and separately exposes a deduplicated response-shape catalog.

- Normalizes every available Evidence Builder 1.0.3 candidate registry from S0047 through S0062, including the byte-identical S0052 duplicate exports represented once.
- Preserves 243 session-level observations and deduplicates them to 241 response shapes and 236 profile/request/response/service/PID tuples.
- Retains all 44 graded decoder definitions unchanged; no candidate tuple overlaps a graded definition tuple.
- Records two exact response shapes and five request tuples repeated across more than one session without treating recurrence alone as semantic validation.
- All candidates remain CANDIDATE, READ_ONLY_DIAGNOSTIC, hidden/evidence-only, excluded from active polling, and ineligible for automatic promotion.
- S0062 field validation remains separate: its 1,608 CAN/OCR pairs support known PHV definitions while its 49 unknown response shapes remain candidates.
- No firmware, Evidence Builder, Evidence Analyzer, Android, acquisition, SD, BLE, session, TWAI, or Wi-Fi-transfer code is changed.

## Counts

- 44 unchanged graded decoder definitions
- 243 candidate session observations
- 241 unique candidate response shapes
- 236 unique candidate request tuples
- 285 normalized catalog rows (44 + 241)
- 280 unique request tuples across graded and candidate scopes (44 + 236)

## Rollback

Immediate rollback target: Toyota_Hybrid_CAN_Database_v0.5.7.xlsx. v0.5.7 remains the narrow S0047 correction and is not overwritten.
