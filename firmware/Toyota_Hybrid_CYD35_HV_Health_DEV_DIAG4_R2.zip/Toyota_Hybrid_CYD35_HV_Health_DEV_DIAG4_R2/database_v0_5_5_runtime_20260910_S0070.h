#pragma once

// Toyota Hybrid CAN Database v0.5.5 runtime overlay for logger core v2.4.3.
// Revision: 2026-09-10 r4 / evidence cutoff S0070 (NHW20 Autel AP200).
//
// Purpose:
//   * Convert the evidence database into a compact runtime decode registry.
//   * Preserve the v0.5.5 evidence grades and the latest reviewed decode results.
//   * Provide fixed segment lengths for ISO-TP decoding plus a SEPARATE explicit
//     read-only active-poll whitelist for normal CYD display operation.
//
// Safety boundary:
//   * Presence in DB_RUNTIME_SIGNALS NEVER authorizes a request to be transmitted.
//   * DB_ACTIVE_DIAGNOSTIC_REQUESTS is the only normal polling whitelist.
//   * CONTROL_WRITE_QUARANTINED records are not present here.
//   * CANDIDATE entries may be observed/classified, but do not populate normal
//     engineering-value screens.
//
// Evidence carried forward through the latest reviewed sessions:
//   * NHW20: S0034/S0016 baseline plus S0055 Hybrid Assistant and S0056
//     Dr. Prius review. SOC/current/V1-V14/R1-R14/TB1-TB3 remain CONFIRMED;
//     battery intake and selected ancillary engine fields remain PROBABLE.
//   * AHV40: S0017 baseline, re-reviewed through S0069.
//     Toyota enhanced diagnostic PID layouts are vehicle/platform/ECU specific.
//     AHV40 21C3 definitions must not inherit Prius Gen 2 / NHW20 byte offsets.
//   * ZVW35: S0018 baseline plus S0060/S0061 supporting sessions and decisive
//     S0062 Autel evidence (1608 CAN/OCR pairs, 1557 agreements). 2181, 2187,
//     218A, 2195 and the normal temperature/current fields remain CONFIRMED.
//     2192 is FIELD_SPECIFIC because S0062 confirms minimum voltage + block
//     count but not the maximum/minimum block-number semantics or max voltage;
//     2198 is FIELD_SPECIFIC because discharge-control limit remains PROBABLE.
//     No 56-individual-cell decoder is claimed.
//   * S0047's 93 Gen-2 response-signature candidates remain in the base header
//     for DIAG EXP evidence collection.

#include <Arduino.h>

enum DbRuntimeDecoder : uint8_t {
  DBR_OBSERVE_ONLY = 0,
  DBR_MODE01_RPM,
  DBR_MODE01_COOLANT,
  DBR_MODE01_INTAKE,
  DBR_MODE01_CATALYST,
  DBR_GEN2_C3,
  DBR_GEN2_C4,
  DBR_GEN2_AUX_V,
  DBR_GEN2_RUNTIME,
  DBR_GEN2_CE,
  DBR_GEN2_CF,
  DBR_GEN2_D0,
  DBR_CAMRY_CE,
  DBR_CAMRY_D0,
  DBR_CAMRY_C3,
  DBR_CAMRY_CF,
  DBR_CAMRY_2105,
  DBR_CAMRY_210F,
  DBR_CAMRY_210C,
  DBR_CAMRY_211F,
  DBR_MODEL_SIGNATURE,
  DBR_PHV_2101,
  DBR_PHV_2161,
  DBR_PHV_2162,
  DBR_PHV_2170,
  DBR_PHV_2171,
  DBR_PHV_2175,
  DBR_PHV_2181,
  DBR_PHV_2187,
  DBR_PHV_218A,
  DBR_PHV_2192,
  DBR_PHV_2195,
  DBR_PHV_2198,
  DBR_ASCII_ONLY
};

struct DbRuntimeSignal {
  const char *profile;
  uint32_t requestId;
  uint32_t responseId;
  uint8_t service;
  uint8_t pid;
  uint8_t expectedDataLength; // bytes after positive service+PID; 0 = variable/observe-only
  DbRuntimeDecoder decoder;
  const char *grade;
  const char *key;
  bool normalDisplay;
};

constexpr char TOYOTA_CAN_DB_RUNTIME_REVISION[] = "0.5.5-runtime-20260910-r4-s0070";

constexpr DbRuntimeSignal DB_RUNTIME_SIGNALS[] = {
  // Prius Gen 2 NHW20 -- latest reviewed field-level boundary:
  //   CONFIRMED: SOC/current, V1-V14, R1-R14, TB1-TB3, MG1/MG2 RPM + torque,
  //              individual MG motor/inverter temperatures, converter temp, aux V and runtime;
  //   PROBABLE: battery intake temperature / selected ancillary engine fields;
  //   CANDIDATE: lower-confidence semantics remain evidence-only.
  // The 21CF tuple stays FIELD_SPECIFIC so the PID itself does not falsely promote
  // its lower-grade intake field merely because the three battery sensors are confirmed.
  {"PRIUS_GEN2", 0x7E0, 0x7E8, 0x01, 0x0C, 2,  DBR_MODE01_RPM,      "CONFIRMED", "NHW20_ENGINE_RPM_010C", true},
  {"PRIUS_GEN2", 0x7E0, 0x7E8, 0x01, 0x05, 1,  DBR_MODE01_COOLANT,  "CONFIRMED", "NHW20_ENGINE_COOLANT_0105", true},
  {"PRIUS_GEN2", 0x7E0, 0x7E8, 0x01, 0x0F, 1,  DBR_MODE01_INTAKE,   "PROBABLE",  "NHW20_ENGINE_INTAKE_010F", true},
  {"PRIUS_GEN2", 0x7E0, 0x7E8, 0x01, 0x3C, 2,  DBR_MODE01_CATALYST, "PROBABLE",  "NHW20_CATALYST_013C", true},
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0xC3, 37, DBR_GEN2_C3,         "FIELD_SPECIFIC", "NHW20_HYBRID_21C3", true},
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0xC4, 15, DBR_GEN2_C4,         "CONFIRMED", "NHW20_HYBRID_21C4_CONVERTER_TEMP", true},
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0x42, 2,  DBR_GEN2_AUX_V,        "CONFIRMED", "NHW20_HYBRID_2142_AUX_VOLTAGE", true},
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0x1F, 2,  DBR_GEN2_RUNTIME,      "CONFIRMED", "NHW20_HYBRID_211F_ENGINE_RUNTIME", true},
  {"PRIUS_GEN2", 0x7E3, 0x7EB, 0x21, 0xCE, 31, DBR_GEN2_CE,         "CONFIRMED", "NHW20_BATTERY_21CE", true},
  {"PRIUS_GEN2", 0x7E3, 0x7EB, 0x21, 0xCF, 28, DBR_GEN2_CF,         "FIELD_SPECIFIC", "NHW20_BATTERY_21CF", true},
  {"PRIUS_GEN2", 0x7E3, 0x7EB, 0x21, 0xD0, 29, DBR_GEN2_D0,         "CONFIRMED", "NHW20_BATTERY_21D0", true},

  // Camry Hybrid Gen 1 AHV40 -- S0017 baseline, re-reviewed through S0052/S0053.
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xCE, 37, DBR_CAMRY_CE,   "CONFIRMED", "AHV40_HYBRID_ECU_21CE_BLOCK_VOLTAGES", true},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xD0, 32, DBR_CAMRY_D0,   "CONFIRMED", "AHV40_HYBRID_ECU_21D0_BLOCK_HEALTH", true},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xC3, 38, DBR_CAMRY_C3,   "CONFIRMED", "AHV40_HYBRID_ECU_21C3_POWERTRAIN_DATA", true},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xCF, 28, DBR_CAMRY_CF,   "CONFIRMED", "AHV40_HYBRID_ECU_21CF_BATTERY_TEMPERATURES", true},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x05, 1,  DBR_CAMRY_2105, "CONFIRMED", "AHV40_HYBRID_ECU_2105_ENGINE_COOLANT_TEMPERATURE", true},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x0F, 1,  DBR_CAMRY_210F, "CONFIRMED", "AHV40_HYBRID_ECU_210F_INTAKE_AIR_TEMPERATURE", true},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x0C, 2,  DBR_CAMRY_210C, "CONFIRMED", "AHV40_HYBRID_ECU_210C_ENGINE_SPEED", true},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x1F, 2,  DBR_CAMRY_211F, "CONFIRMED", "AHV40_HYBRID_ECU_211F_ENGINE_RUN_TIME", false},
  {"CAMRY_HYBRID_GEN1", 0x7E0, 0x7E8, 0x21, 0xC1, 0,  DBR_MODEL_SIGNATURE, "CONFIRMED", "AHV40_ENGINE_ECU_21C1_MODEL_SIGNATURE", false},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xC1, 0,  DBR_MODEL_SIGNATURE, "CONFIRMED", "AHV40_HYBRID_ECU_21C1_MODEL_SIGNATURE", false},
  {"CAMRY_HYBRID_GEN1", 0x7E3, 0x7EB, 0x21, 0x01, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "AHV40_BATTERY_ECU_2101_SOC_CURRENT_VOLTAGE", false},
  {"CAMRY_HYBRID_GEN1", 0x7E3, 0x7EB, 0x21, 0x02, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "AHV40_BATTERY_ECU_2102_TEMPERATURES", false},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x22, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "AHV40_HYBRID_ECU_2122_MG_STATOR_TEMPERATURES", false},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x2B, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "AHV40_HYBRID_ECU_212B_INVERTER_TEMPERATURES", false},

  // Prius PHV Gen 1 ZVW35 -- field-level review through S0062.
  // 2101 has 24 data bytes in the bundled transaction; only graded fields are decoded.
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x01, 24, DBR_PHV_2101, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2101_ENGINE_AND_SOC", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x61, 5,  DBR_PHV_2161, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2161_MG1_STATUS", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x62, 5,  DBR_PHV_2162, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2162_MG2_STATUS", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x67, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "ZVW35_HYBRID_ECU_2167_MG1_TORQUE", false},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x68, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "ZVW35_HYBRID_ECU_2168_MG2_TORQUE", false},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x70, 4,  DBR_PHV_2170, "CONFIRMED", "ZVW35_HYBRID_ECU_2170_MG1_INVERTER_TEMPERATURE", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x71, 4,  DBR_PHV_2171, "CONFIRMED", "ZVW35_HYBRID_ECU_2171_MG2_INVERTER_TEMPERATURE", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x74, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "ZVW35_HYBRID_ECU_2174_BOOST_CONVERTER_TEMPERATURES", false},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x75, 6,  DBR_PHV_2175, "CONFIRMED", "ZVW35_HYBRID_ECU_2175_INVERTER_COOLANT_AND_PUMP", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x81, 22, DBR_PHV_2181, "CONFIRMED", "ZVW35_HYBRID_ECU_2181_EIGHT_BLOCK_VOLTAGES", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x87, 32, DBR_PHV_2187, "CONFIRMED", "ZVW35_HYBRID_ECU_2187_BATTERY_TEMPERATURES", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x8A, 4,  DBR_PHV_218A, "CONFIRMED", "ZVW35_HYBRID_ECU_218A_POWER_RESOURCE_CURRENTS", false},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x92, 22, DBR_PHV_2192, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2192_BLOCK_EXTREMA", false},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x95, 8,  DBR_PHV_2195, "CONFIRMED", "ZVW35_HYBRID_ECU_2195_BLOCK_INTERNAL_RESISTANCE", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x98, 8,  DBR_PHV_2198, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2198_BATTERY_CURRENT_AND_SOC", true},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x9B, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "ZVW35_HYBRID_ECU_219B_BATTERY_FAN_STATUS", false},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x46, 0,  DBR_OBSERVE_ONLY, "CANDIDATE", "ZVW35_HYBRID_ECU_2146_SIGNATURE", false},
  {"PRIUS_PHV_GEN1", 0x7E0, 0x7E8, 0x21, 0xC1, 0,  DBR_MODEL_SIGNATURE, "CONFIRMED", "ZVW35_ENGINE_ECU_21C1_MODEL_SIGNATURE", false},
  {"PRIUS_PHV_GEN1", 0x7E0, 0x7E8, 0x09, 0x02, 0,  DBR_ASCII_ONLY, "CONFIRMED", "ZVW35_ENGINE_ECU_0902_VIN", false},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0xC2, 5,  DBR_ASCII_ONLY, "CONFIRMED", "ZVW35_HYBRID_ECU_21C2_ECU_CODE", false},
};

constexpr size_t DB_RUNTIME_SIGNAL_COUNT = sizeof(DB_RUNTIME_SIGNALS) / sizeof(DB_RUNTIME_SIGNALS[0]);

// ---------------- Explicit active read-only polling whitelist ----------------
// This table is intentionally separate from DB_RUNTIME_SIGNALS. A database row
// can be decoded passively without being eligible for CYD transmission.
// Only CONFIRMED / FIELD_SPECIFIC / selected PROBABLE read-only requests needed
// by MAIN, TEMP, and HV are listed here. No CANDIDATE or write/control request
// is eligible for automatic polling.
struct DbActiveDiagnosticRequest {
  const char *profile;
  uint32_t requestId;
  uint32_t responseId;
  uint8_t service;
  uint8_t pid;
  uint32_t periodMs;
  const char *grade;
  const char *key;
};

// Read-only model-code discovery. This is not part of the normal cyclic plan;
// it is used only to resolve/verify profile identity before profile-specific
// polling, particularly to prevent the historical ZVW35->AHV40 heuristic error.
constexpr DbActiveDiagnosticRequest DB_IDENTITY_DISCOVERY_REQUEST = {
  "IDENTITY", 0x7E0, 0x7E8, 0x21, 0xC1, 2000, "READ_ONLY_IDENTITY", "MODEL_SIGNATURE_21C1"
};

constexpr DbActiveDiagnosticRequest DB_ACTIVE_DIAGNOSTIC_REQUESTS[] = {
  // Prius Gen 2 NHW20. S0070 confirms MG RPM/torque and converter/aux/runtime fields. Engine RPM remains from confirmed 21C3.
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0xC3, 1200, "FIELD_SPECIFIC","NHW20_HYBRID_21C3"},
  {"PRIUS_GEN2", 0x7E3, 0x7EB, 0x21, 0xCE, 1200, "CONFIRMED",     "NHW20_BATTERY_21CE"},
  {"PRIUS_GEN2", 0x7E3, 0x7EB, 0x21, 0xCF, 2500, "FIELD_SPECIFIC","NHW20_BATTERY_21CF"},
  {"PRIUS_GEN2", 0x7E0, 0x7E8, 0x01, 0x05, 3000, "CONFIRMED",     "NHW20_ENGINE_COOLANT_0105"},
  {"PRIUS_GEN2", 0x7E0, 0x7E8, 0x01, 0x0F, 6000, "PROBABLE",      "NHW20_ENGINE_INTAKE_010F"},
  {"PRIUS_GEN2", 0x7E3, 0x7EB, 0x21, 0xD0, 6000, "CONFIRMED",     "NHW20_BATTERY_21D0"},
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0xC4, 6000, "CONFIRMED",     "NHW20_HYBRID_21C4_CONVERTER_TEMP"},
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0x42, 8000, "CONFIRMED",     "NHW20_HYBRID_2142_AUX_VOLTAGE"},
  {"PRIUS_GEN2", 0x7E2, 0x7EA, 0x21, 0x1F, 10000,"CONFIRMED",     "NHW20_HYBRID_211F_ENGINE_RUNTIME"},
  {"PRIUS_GEN2", 0x7E0, 0x7E8, 0x01, 0x3C, 8000, "PROBABLE",      "NHW20_CATALYST_013C"},

  // Camry Hybrid Gen 1 AHV40. Alternative 7E3 2101/2102 and 2122/212B
  // catalog candidates remain evidence-only and are not transmitted.
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x0C, 1000, "CONFIRMED", "AHV40_HYBRID_ECU_210C_ENGINE_SPEED"},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xCE, 1200, "CONFIRMED", "AHV40_HYBRID_ECU_21CE_BLOCK_VOLTAGES"},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xC3, 1500, "CONFIRMED", "AHV40_HYBRID_ECU_21C3_POWERTRAIN_DATA"},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xCF, 2000, "CONFIRMED", "AHV40_HYBRID_ECU_21CF_BATTERY_TEMPERATURES"},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x05, 2500, "CONFIRMED", "AHV40_HYBRID_ECU_2105_ENGINE_COOLANT_TEMPERATURE"},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0x0F, 5000, "CONFIRMED", "AHV40_HYBRID_ECU_210F_INTAKE_AIR_TEMPERATURE"},
  {"CAMRY_HYBRID_GEN1", 0x7E2, 0x7EA, 0x21, 0xD0, 6000, "CONFIRMED", "AHV40_HYBRID_ECU_21D0_BLOCK_HEALTH"},

  // Prius PHV Gen 1 ZVW35. Reviewed through S0062. Lower-grade subfields inside
  // FIELD_SPECIFIC responses may be displayed with a P marker but do not
  // promote candidate semantics or make candidate fields eligible for polling.
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x01, 1500, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2101_ENGINE_AND_SOC"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x81, 1500, "CONFIRMED",      "ZVW35_HYBRID_ECU_2181_EIGHT_BLOCK_VOLTAGES"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x98, 1500, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2198_BATTERY_CURRENT_AND_SOC"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x61, 2500, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2161_MG1_STATUS"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x62, 2500, "FIELD_SPECIFIC", "ZVW35_HYBRID_ECU_2162_MG2_STATUS"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x87, 2500, "CONFIRMED",      "ZVW35_HYBRID_ECU_2187_BATTERY_TEMPERATURES"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x70, 3000, "CONFIRMED",      "ZVW35_HYBRID_ECU_2170_MG1_INVERTER_TEMPERATURE"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x71, 3000, "CONFIRMED",      "ZVW35_HYBRID_ECU_2171_MG2_INVERTER_TEMPERATURE"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x75, 4000, "CONFIRMED",      "ZVW35_HYBRID_ECU_2175_INVERTER_COOLANT_AND_PUMP"},
  {"PRIUS_PHV_GEN1", 0x7E2, 0x7EA, 0x21, 0x95, 8000, "CONFIRMED",      "ZVW35_HYBRID_ECU_2195_BLOCK_INTERNAL_RESISTANCE"},
};

constexpr size_t DB_ACTIVE_DIAGNOSTIC_REQUEST_COUNT =
    sizeof(DB_ACTIVE_DIAGNOSTIC_REQUESTS) / sizeof(DB_ACTIVE_DIAGNOSTIC_REQUESTS[0]);

