# Toyota Hybrid CAN Database schema 1.1.1

Schema 1.1.1 is an additive correction to schema 1.1.0. It preserves the 44 graded decoder definitions and introduces a separate `candidate_response_signatures` registry for discovery evidence.

## Count semantics

- **44 graded decoder definitions:** formula/semantic records carried forward unchanged from v0.5.6.
- **93 candidate response shapes:** complete S0047 discovery export.
- **91 unique candidate request tuples:** two request tuples each have two response-shape variants.
- **91 non-Mode09 candidate shapes:** a separate coincidental count obtained by excluding the two Mode 09 identity shapes.
- **137 catalog rows:** 44 graded definitions + 93 candidate shapes.
- **135 unique request tuples:** 44 graded tuples + 91 candidate tuples; overlap is zero.

## Candidate safety policy

Every candidate is CANDIDATE, READ_ONLY_DIAGNOSTIC, hidden/evidence-only, excluded from active polling, and marked `automatic_promotion_allowed=false`. A response signature records observed existence and shape only; it does not validate a formula or signal meaning.
