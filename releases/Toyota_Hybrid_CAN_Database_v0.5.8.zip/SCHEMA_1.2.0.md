# Toyota Hybrid CAN Database schema 1.2.0

Schema 1.2.0 adds a normalized, multi-session candidate registry without changing the 44 graded decoder definitions.

## Registry layers

- **243 session observations:** every candidate row from the nine selected Evidence Builder 1.0.3 session exports, with source ZIP/member hashes and session provenance.
- **241 unique response shapes:** deduplicated by profile, request/response IDs, service, PID, response length, and response prefix.
- **236 unique request tuples:** deduplicated without response length/prefix.
- **44 graded definitions:** unchanged from v0.5.7.

Two exact shapes and five request tuples recur across sessions. Recurrence strengthens observation confidence but does not validate formula, units, or semantics. All candidates remain hidden/evidence-only, excluded from active polling, and automatic promotion is disabled.
