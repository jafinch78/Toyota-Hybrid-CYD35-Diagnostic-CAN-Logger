# DEV2.1 SPEED screen refinement

DEV2.1 preserves DEV2 and adds the confirmed MG rotational speeds to the SPEED page.

SPEED compact metrics now show:
- engine coolant temperature
- ICE RPM
- MG1 RPM
- MG2 RPM
- SOC
- HV pack voltage
- block-voltage spread
- HV power
- selected speed source

MG1/MG2 RPM use the existing runtime freshness/capability gate. Stale or unsupported data renders as `---`.

The wheel-speed decoder remains intentionally unbound until the exact final S0077/S0078 byte-level mapping is recovered from the Decode Wheel Speed Data work. Conflicting retained summaries were found, so DEV2.1 does not guess between them.
