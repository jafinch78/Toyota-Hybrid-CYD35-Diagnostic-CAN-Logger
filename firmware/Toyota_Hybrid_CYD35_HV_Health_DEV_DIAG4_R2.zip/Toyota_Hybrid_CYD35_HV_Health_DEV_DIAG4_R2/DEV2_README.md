# Toyota Hybrid CYD35 HV Health DEV2

DEV2 extends the functioning DEV1 / R2.5-derived session logger with the planned SPEED and WHEELS display architecture.

## What changed from DEV1

Page order is now:
1. MAIN
2. SPEED
3. WHEELS
4. TEMP
5. HV
6. BLOCKS
7. TREND
8. POWER
9. HEALTH
10. SYSTEM
11. DIAG EXP

### SPEED
- Large MPH display.
- Source label supports AUTO, VEHICLE, WHEEL AVG, and future GPS.
- AUTO priority is validated vehicle speed, then validated four-wheel average, then GPS.
- Compact MAIN metrics below speed: engine temperature, ICE RPM, SOC, HV voltage, block dV and HV power.
- If no validated speed source is fresh, the page shows `--- MPH` rather than inventing a value.

### WHEELS
- FL, FR, RL and RR wheel speed in MPH.
- Calculated wheel RPM for each wheel using configured tire geometry.
- Average wheel speed and maximum wheel-to-wheel speed delta.
- Default tire geometry is 195/65R15, isolated from the CAN decoder so it can become user configurable.

## Decoder boundary

S0075 was the ABS/VSC/TRAC discovery session. Later project context identifies S0077 as the session that confirmed individual Gen 2 wheel speeds and S0078 as independent corroboration. The exact S0077/S0078 byte-level mapping is not present in the currently retrievable Library/chat evidence used for this DEV2 build.

For that reason DEV2 deliberately does **not** promote any guessed wheel decoder, Vass cross-generation mapping, or Gen 3 `7B0/2103` definition into the NHW20 runtime. Instead it adds decoder-facing setters:

- `setValidatedVehicleSpeedMph(...)`
- `setValidatedWheelSpeedsMph(fl, fr, rl, rr, ...)`

The SPEED and WHEELS pages become live as soon as the confirmed Gen 2 decoder calls those setters. Until then WHEELS explicitly reports that it is waiting for the validated S0077/S0078 mapping.

## Tire calculation

DEV2 uses physical tire geometry:

```
sidewall_mm = width_mm * aspect_ratio / 100
diameter_mm = rim_inches * 25.4 + 2 * sidewall_mm
circumference_m = pi * diameter_mm / 1000
wheel_rpm = mph * 1609.344 / 60 / circumference_m
```

No tire-size correction is applied to the underlying CAN speed value; tire geometry is used only to derive wheel RPM and can later support calibration/diagnostics.

## Preserved behavior

DEV2 retains the functioning DEV1 acquisition/session logger, read-only diagnostics, external-tester coexistence, BLE, SD logging, Wi-Fi maintenance mode, S0070 Gen 2 MG decoding, health pages, and existing safety boundaries.

## Validation required

Before treating SPEED/WHEELS as fully active on NHW20:
- merge the exact S0077/S0078 confirmed wheel-speed mapping;
- compare all four displayed wheel speeds with the Autel ABS/VSC live-data page;
- verify wheel order with controlled low-speed turns if needed;
- compare average wheel speed against combination-meter/GPS reference;
- validate reverse behavior separately (wheel speeds are currently constrained nonnegative);
- confirm tire-size/RPM calculation against the installed tire size.

This remains a development checkpoint until Arduino/ESP32 compilation and vehicle testing are completed.
