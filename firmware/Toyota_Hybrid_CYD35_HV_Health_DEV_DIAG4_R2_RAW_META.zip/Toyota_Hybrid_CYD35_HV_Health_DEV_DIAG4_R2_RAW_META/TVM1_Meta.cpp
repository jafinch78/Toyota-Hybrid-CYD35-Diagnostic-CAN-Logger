#include "TVM1_Meta.h"
#include <string.h>

uint32_t tvm1_crc32(const uint8_t *data, size_t len) {
  uint32_t crc = 0xFFFFFFFFu;
  for (size_t i = 0; i < len; ++i) {
    crc ^= data[i];
    for (uint8_t b = 0; b < 8; ++b) {
      crc = (crc >> 1) ^ (0xEDB88320u & (0u - (crc & 1u)));
    }
  }
  return crc ^ 0xFFFFFFFFu;
}
void tvm1_put_u16(uint8_t *p, uint16_t v){ p[0]=uint8_t(v); p[1]=uint8_t(v>>8); }
void tvm1_put_u32(uint8_t *p, uint32_t v){ for(int i=0;i<4;++i) p[i]=uint8_t(v>>(8*i)); }
void tvm1_put_u64(uint8_t *p, uint64_t v){ for(int i=0;i<8;++i) p[i]=uint8_t(v>>(8*i)); }

Tvm1Writer::Tvm1Writer() : file_(nullptr), sequence_(0) { memset(record_,0,sizeof(record_)); }

bool Tvm1Writer::begin(File &file, uint32_t sessionNumber, uint64_t sessionCreateUs) {
  file_ = &file;
  sequence_ = 0;
  uint8_t h[TVM1_HEADER_SIZE] = {};
  h[0]='T'; h[1]='V'; h[2]='M'; h[3]='1';
  h[4]=1; h[5]=0;
  tvm1_put_u16(h+6, TVM1_HEADER_SIZE);
  tvm1_put_u32(h+8, sessionNumber);
  tvm1_put_u32(h+12, 0);
  tvm1_put_u64(h+16, sessionCreateUs);
  tvm1_put_u32(h+24, tvm1_crc32(h,24));
  tvm1_put_u32(h+28, 0);
  return file_->write(h,sizeof(h)) == sizeof(h);
}

bool Tvm1Writer::append(uint16_t recordType, uint8_t streamId, uint8_t flags,
                        uint64_t timeUs, const uint8_t *payload, uint16_t payloadLen) {
  if (!file_ || payloadLen > TVM1_MAX_PAYLOAD) return false;
  const uint16_t total = uint16_t(TVM1_RECORD_BASE_SIZE + payloadLen);
  memset(record_,0,total);
  tvm1_put_u16(record_+0, TVM1_SYNC_WORD);
  tvm1_put_u16(record_+2, total);
  tvm1_put_u16(record_+4, recordType);
  record_[6] = streamId;
  record_[7] = flags;
  tvm1_put_u32(record_+8, ++sequence_);
  tvm1_put_u64(record_+12, timeUs);
  if (payloadLen && payload) memcpy(record_+20,payload,payloadLen);
  tvm1_put_u32(record_+20+payloadLen, tvm1_crc32(record_,20+payloadLen));
  if (file_->write(record_, total) != total) { --sequence_; return false; }
  return true;
}

bool Tvm1Writer::flush() {
  if (!file_) return false;
  file_->flush();
  return true;
}
