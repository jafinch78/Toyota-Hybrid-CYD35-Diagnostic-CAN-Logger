# HV Health DEV2.2

DEV2.2 refines the SPEED page while preserving the functioning DEV2.1 / DEV1 / R2.5-derived logger core.

## SPEED page

- Large MPH display remains.
- Engine coolant temperature and ICE RPM remain.
- MG1 and MG2 RPM remain.
- SOC and HV pack voltage remain.
- HV battery block delta-V remains.
- Pack power is removed from SPEED.
- MG1 motor temperature and MG2 motor temperature are displayed instead.
- Persistent `SOURCE:` text is removed from the page. Speed-source selection remains internal architecture for a later settings UI.
- Tire-size selection likewise remains a later settings/UI item rather than consuming SPEED screen space.

## Evidence behavior

MG motor temperatures use the existing validated runtime fields and freshness gates. Unsupported or stale values display `---`.

## Preservation

No acquisition, session logging, diagnostic coexistence, BLE, SD, Wi-Fi, or safety behavior is intentionally changed by this checkpoint.
