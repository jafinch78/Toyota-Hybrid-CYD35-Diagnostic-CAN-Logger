from pathlib import Path
p = Path('/mnt/data/diag4r2_work/Toyota_Hybrid_CYD35_HV_Health_DEV_DIAG4/logger_v2_4_3_core.inc')
s = p.read_text()
required = [
    'MALLOC_CAP_INTERNAL',
    'heap_caps_check_integrity_all',
    'DIAG4_PRE_START',
    'DIAG4_POST_DIR',
    'DIAG4_POST_RAW',
    'DIAG4_POST_DECODED',
    'DIAG4_POST_DIAGNOSTIC',
    'DIAG4_POST_EVENTS',
    'DIAG4_POST_SYNC',
    'DIAG4_POST_EXTERNAL_DIAG',
    'DIAG4_PRE_SESSION_OPEN',
    'DIAG4_POST_SESSION_OPEN',
    'DIAG4_PRE_METADATA',
    'DIAG4_POST_METADATA',
    'DIAG4_START_DONE',
    'DIAG4_BLE_NOTIFY_PRE',
    'DIAG4_BLE_NOTIFY_POST',
    'DIAG4_ACTIVE_2S',
    'DIAG4_ACTIVE_5S',
    'DIAG4_STOP_BEGIN',
    'DIAG4_STOP_POST_FLUSH',
    'DIAG4_STOP_POST_FILES',
    'DIAG4_STOP_DONE',
    'DIAG4_BLE_CONNECTED',
    'DIAG4_BLE_DISCONNECTED',
    'DEV_DIAG4_RESET_AUDIT.CSV',
    'RTC_DATA_ATTR',
    'esp_reset_reason()',
]
missing = [x for x in required if x not in s]
assert not missing, f'Missing DIAG4-R2 instrumentation: {missing}'
assert 'constexpr uint16_t CAN_QUEUE_LENGTH = 768;' in s
assert 'diagnosticQueue = xQueueCreate(64, sizeof(CapturedFrame));' in s
print('PASS: DIAG4-R2 static instrumentation contract satisfied')
