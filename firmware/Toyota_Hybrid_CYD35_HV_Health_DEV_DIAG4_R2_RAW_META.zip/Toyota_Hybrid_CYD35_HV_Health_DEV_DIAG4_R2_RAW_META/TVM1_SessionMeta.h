#pragma once
#include "TVM1_Meta.h"
#include <stdint.h>

class Tvm1SessionMeta {
public:
  Tvm1SessionMeta();
  bool begin(File &file, uint32_t sessionNumber, uint64_t sessionCreateUs,
             const char *loggerName, const char *firmwareVersion,
             const char *boardProfile, const char *buildId,
             const char *runtimeDatabase, uint32_t canBitrate);
  bool writeRawFileOpen(uint16_t fileIndex, const char *filename, uint64_t timeUs);
  bool writeRawFileClose(uint16_t fileIndex, uint64_t recordsPersisted,
                         uint64_t bytesPersisted, uint64_t timeUs);
  bool writeClockSync(uint16_t sequence, uint64_t receiveUs, uint64_t sendUs,
                      const char *source);
  bool writeEvent(uint64_t timeUs, const char *severity, const char *eventName,
                  int32_t profile = -1, int32_t confidence = -1);
  bool writeCounters(uint64_t timeUs, uint64_t rxRecords, uint64_t txRecords,
                     uint64_t persistedRecords, uint64_t queueDrops,
                     uint64_t storageDroppedRecords, uint32_t queueHighWater,
                     uint32_t protocolErrors);
  bool writeHealthSnapshot(uint64_t timeUs);
  bool writeStorageHealth(uint64_t timeUs, uint64_t cardBytes, uint64_t usedBytes);
  bool writeDiagnosticState(uint64_t timeUs, bool enabled, uint32_t profile, uint32_t confidence);
  bool writeBusState(uint64_t timeUs, bool normalMode, uint32_t bitrate, uint32_t externalTesterRecent);
  bool writeStreamStop(uint16_t reasonCode, uint64_t timeUs);
  bool writeSessionClose(bool clean, uint16_t reasonCode, uint64_t timeUs);
  bool flush();
  void end();
  bool active() const { return active_; }

private:
  Tvm1Writer writer_;
  bool active_;
  bool appendString(uint8_t *buffer, uint16_t capacity, uint16_t &offset, const char *value);
  uint16_t eventCode(const char *eventName) const;
  uint8_t severityCode(const char *severity) const;
};
