# DEV2.5 — Additive PLOT recorder

Baseline: DEV2.4. `logger_v2_4_3_core.inc` is byte-for-byte unchanged from DEV2.4.

## Added behavior

DEV2.5 adds a wrapper-only PLOT recorder that follows the existing Sxxxx logging lifecycle. When the existing logger is active it creates `PLOT.CSV` in that same session folder; when logging stops it closes the file and creates `PLOT_SUMMARY.JSON`.

Sampling is 5 Hz (200 ms) to limit SD load. PLOT does not transmit CAN, alter diagnostic polling, alter BLE behavior, or change any decoder.

`PLOT.CSV` includes time, session/profile, BLE link and sync-record count, SOC, pack voltage/current/power, block delta-V, B01-B14 voltages, B01-B14 resistances, battery temperatures, MG1/MG2 motor temperatures, ICE/MG RPMs, validated vehicle/wheel speed fields when available, signal ages, and data-quality label. Stale/unavailable engineering values are blank.

## BLE corroboration

PLOT uses the same Sxxxx directory and ESP32 monotonic time base as the existing `SYNC.CSV` and `EVENTS.CSV`. Exact BLE E2/E3 synchronization records remain in `SYNC.CSV`; BLE markers remain in `EVENTS.CSV`. PLOT rows include BLE connection state and cumulative BLE sync count so offline tools can cross-check continuity without duplicating the synchronization protocol.

## Regression boundary

Only `Toyota_Hybrid_CYD35_HV_Health_DEV2_5.ino` changes relative to DEV2.4, plus documentation/manifests. The logger core, databases, and Wi-Fi helper headers are unchanged.

Actual Arduino/ESP32 compile and SD-card timing still require local hardware/toolchain validation.
