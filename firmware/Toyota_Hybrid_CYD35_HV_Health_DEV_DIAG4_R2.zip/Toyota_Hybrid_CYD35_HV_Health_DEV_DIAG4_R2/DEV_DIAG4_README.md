# Toyota Hybrid CYD35 HV Health DEV-DIAG4

Controlled A/B test branch based directly on the packaged DEV2.5 source.

## Functional change

Exactly one functional source constant is changed:

- `CAN_QUEUE_LENGTH`: `1024` -> `768`

`CapturedFrame` is 24 bytes, so the queue payload reservation is reduced by:

- `(1024 - 768) * 24 = 6144 bytes` (6 KiB)

This is the same primary `canQueue` observed filling to 1024 during the synchronous START path. There is not a second START-specific CAN queue allocation. With this build, the same queue will saturate at 768 during START.

## Purpose

Retain DEV2.5 diagnostic capability, display functionality, PLOT recorder, logging, BLE sync, SD behavior, and diagnostic runtime while testing whether recovering approximately 6 KiB of internal queue storage provides adequate stability margin.

## Expected tradeoff

The shorter queue reduces buffering during multi-second synchronous START operations. If CAN production exceeds draining during START, saturation/drop onset will occur earlier than with 1024 entries. Review `can_queue_drops` and DIAG/resource telemetry after testing.

## Controlled-test requirement

Use the same CYD board, SD card, Android app, vehicle, Autel/tester state, compiler/toolchain, and START/STOP sequence used for prior DIAG tests. A useful acceptance gate is at least five consecutive BLE START/STOP cycles with no panic/reset, no SD-NOT-READY failure, and clean session closure.
